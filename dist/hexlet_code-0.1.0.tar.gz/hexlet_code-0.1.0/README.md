### Tests, maintainability and linter status:
[![Actions Status](https://github.com/Unbeliev4ble/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Unbeliev4ble/python-project-50/actions)
[![Test Coverage](https://api.codeclimate.com/v1/badges/52a3e1b30903d66b16eb/test_coverage)](https://codeclimate.com/github/Unbeliev4ble/python-project-50/test_coverage)
[![Maintainability](https://api.codeclimate.com/v1/badges/52a3e1b30903d66b16eb/maintainability)](https://codeclimate.com/github/Unbeliev4ble/python-project-50/maintainability)

### Asciinema demonstarations: 
1. Comparing plain.json files
[![asciicast](https://asciinema.org/a/d2ltyMMZVjHWAvyvNdsdU3Rnv.svg)](https://asciinema.org/a/d2ltyMMZVjHWAvyvNdsdU3Rnv)
2. Comparing nested.json and .yaml files. Stylish output format.
[![asciicast](https://asciinema.org/a/MgjmJibyu464GkGnSdxCmQuT4.svg)](https://asciinema.org/a/MgjmJibyu464GkGnSdxCmQuT4)
3. Comparing nested.json files. 
Plain output format.
[![asciicast](https://asciinema.org/a/dkMsdK3bsLTXyIhXVRBeqptUx.svg)](https://asciinema.org/a/dkMsdK3bsLTXyIhXVRBeqptUx)