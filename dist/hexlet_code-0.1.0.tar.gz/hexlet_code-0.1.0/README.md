### Hexlet tests and linter status:
[![Actions Status](https://github.com/Unbeliev4ble/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Unbeliev4ble/python-project-50/actions)

Asciinema demonstaration of comparing 2 .json files:
[![asciicast](https://asciinema.org/a/d2ltyMMZVjHWAvyvNdsdU3Rnv.svg)](https://asciinema.org/a/d2ltyMMZVjHWAvyvNdsdU3Rnv)