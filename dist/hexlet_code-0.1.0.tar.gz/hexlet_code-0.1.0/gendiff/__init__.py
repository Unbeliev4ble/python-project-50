from gendiff.gen_diff import generate_diff
from gendiff.get_data import get_data


__all__ = ('generate_diff',
           'get_data'
           )
