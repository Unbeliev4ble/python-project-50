from gendiff.gen_diff import generate_diff


__all__ = ('generate_diff',
           )
