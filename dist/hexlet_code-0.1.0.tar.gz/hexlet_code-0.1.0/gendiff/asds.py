from gendiff import generate_diff

file1 = '/home/frost/projects/file1.json'
file2 = '/home/frost/projects/file2.json'
print(generate_diff(file1, file2))
