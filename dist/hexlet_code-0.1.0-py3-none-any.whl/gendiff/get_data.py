import json
import yaml
import pprint


def get_data(file_path: str) -> dict:
    if file_path.endswith('.json'):
        return json.load(open(file_path))
    elif file_path.endswith(('.yaml', '.yml')):
        return yaml.safe_load(open(file_path))



# print(get_data('./tests/fixtures/file2_nested.yaml'))
# pprint.pprint(get_data('./tests/fixtures/file2_nested.yaml'), sort_dicts=0)